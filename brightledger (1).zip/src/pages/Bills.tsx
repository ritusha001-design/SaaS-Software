import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, getDocs, addDoc, orderBy, serverTimestamp, updateDoc, doc } from 'firebase/firestore';
import { Organization, Bill } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import { ClipboardList, Search, Plus, Clock, CheckCircle2, AlertCircle } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface BillsProps {
  org: Organization;
}

export default function Bills({ org }: BillsProps) {
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [newBill, setNewBill] = useState({
    supplier: '',
    billNumber: '',
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    subtotal: '',
    vatTotal: ''
  });

  const fetchBills = async () => {
    setLoading(true);
    const path = `organizations/${org.id}/bills`;
    try {
      const q = query(
        collection(db, 'organizations', org.id, 'bills'),
        orderBy('dueDate', 'asc')
      );
      const snap = await getDocs(q);
      setBills(snap.docs.map(d => ({ id: d.id, ...d.data() } as Bill)));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, path);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBills();
  }, [org.id]);

  const handleAddBill = async (e: React.FormEvent) => {
    e.preventDefault();
    const path = `organizations/${org.id}/bills`;
    const sub = parseFloat(newBill.subtotal);
    const vat = parseFloat(newBill.vatTotal) || 0;
    try {
      const data = {
        orgId: org.id,
        supplier: newBill.supplier,
        billNumber: newBill.billNumber,
        issueDate: newBill.issueDate,
        dueDate: newBill.dueDate,
        subtotal: sub,
        vatTotal: vat,
        total: sub + vat,
        status: 'unpaid',
        createdAt: serverTimestamp()
      };
      await addDoc(collection(db, 'organizations', org.id, 'bills'), data);
      setShowAdd(false);
      fetchBills();
      setNewBill({
        supplier: '',
        billNumber: '',
        issueDate: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        subtotal: '',
        vatTotal: ''
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const handleMarkPaid = async (billId: string) => {
    const path = `organizations/${org.id}/bills/${billId}`;
    try {
      await updateDoc(doc(db, 'organizations', org.id, 'bills', billId), {
        status: 'paid',
        updatedAt: serverTimestamp()
      });
      fetchBills();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const filtered = bills.filter(b => 
    b.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.billNumber?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <ClipboardList className="text-indigo-600" />
            Supplier Bills
          </h1>
          <p className="text-slate-500 font-medium mt-1">Track and manage what you owe suppliers</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95"
        >
          <Plus size={20} />
          <span>Add New Bill</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Total Outstanding</span>
          <p className="text-3xl font-black text-slate-900">
            {formatCurrency(bills.filter(b => b.status === 'unpaid').reduce((acc, b) => acc + b.total, 0), org.currency)}
          </p>
          <div className="mt-4 h-2 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-rose-500 rounded-full" 
              style={{ width: `${(bills.filter(b => b.status === 'unpaid').length / (bills.length || 1)) * 100}%` }}
            ></div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Due within 7 days</span>
          <p className="text-3xl font-black text-rose-600">
            {formatCurrency(bills.filter(b => {
              const diff = new Date(b.dueDate).getTime() - Date.now();
              return b.status === 'unpaid' && diff > 0 && diff < 7 * 24 * 60 * 60 * 1000;
            }).reduce((acc, b) => acc + b.total, 0), org.currency)}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder="Search supplier or bill #..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-indigo-500/20 transition-all"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Supplier</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Due Date</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Total</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td className="px-6 py-4"><div className="h-4 bg-slate-100 rounded w-40"></div></td>
                    <td className="px-6 py-4"><div className="h-4 bg-slate-100 rounded w-24"></div></td>
                    <td className="px-6 py-4"><div className="h-6 bg-slate-100 rounded-full w-20"></div></td>
                    <td className="px-6 py-4"><div className="h-4 bg-slate-100 rounded w-20 ml-auto"></div></td>
                    <td className="px-6 py-4"></td>
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-16 h-16 rounded-full bg-slate-50 flex items-center justify-center text-slate-300">
                        <ClipboardList size={32} />
                      </div>
                      <p className="text-slate-500 font-medium tracking-tight text-lg">No bills found</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-900">{b.supplier}</span>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">#{b.billNumber || 'NO-REF'}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Clock size={14} className="text-slate-400" />
                        <span className="text-sm font-medium text-slate-600">{b.dueDate}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {b.status === 'paid' ? (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-emerald-50 text-emerald-600 border border-emerald-100">
                          <CheckCircle2 size={10} /> Paid
                        </span>
                      ) : (
                        <span className={cn(
                          "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border",
                          new Date(b.dueDate) < new Date() 
                            ? "bg-rose-50 text-rose-600 border-rose-100" 
                            : "bg-amber-50 text-amber-600 border-amber-100"
                        )}>
                          {new Date(b.dueDate) < new Date() ? <AlertCircle size={10} /> : <Clock size={10} />}
                          {new Date(b.dueDate) < new Date() ? 'Overdue' : 'Unpaid'}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm font-black text-slate-900 text-right">
                      {formatCurrency(b.total, org.currency)}
                    </td>
                    <td className="px-6 py-4 text-center">
                      {b.status === 'unpaid' && (
                        <button
                          onClick={() => handleMarkPaid(b.id)}
                          className="text-xs font-black text-indigo-600 hover:text-indigo-700 uppercase tracking-widest py-1 px-3 hover:bg-indigo-50 rounded-lg transition-all"
                        >
                          Mark Paid
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdd(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-xl bg-white rounded-[32px] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-slate-100 bg-slate-50/50">
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Add Supplier Bill</h2>
                <p className="text-slate-500 font-medium">Log a new bill for payment</p>
              </div>

              <form onSubmit={handleAddBill} className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Supplier Name</label>
                    <input
                      required
                      type="text"
                      placeholder="e.g. Amazon Web Services"
                      value={newBill.supplier}
                      onChange={(e) => setNewBill(prev => ({ ...prev, supplier: e.target.value }))}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Bill Reference</label>
                    <input
                      type="text"
                      placeholder="e.g. INV-2024-001"
                      value={newBill.billNumber}
                      onChange={(e) => setNewBill(prev => ({ ...prev, billNumber: e.target.value }))}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Issue Date</label>
                    <input
                      required
                      type="date"
                      value={newBill.issueDate}
                      onChange={(e) => setNewBill(prev => ({ ...prev, issueDate: e.target.value }))}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Due Date</label>
                    <input
                      required
                      type="date"
                      value={newBill.dueDate}
                      onChange={(e) => setNewBill(prev => ({ ...prev, dueDate: e.target.value }))}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Subtotal</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">
                        {org.currency === 'GBP' ? '£' : org.currency === 'USD' ? '$' : '€'}
                      </span>
                      <input
                        required
                        type="number"
                        step="0.01"
                        value={newBill.subtotal}
                        onChange={(e) => setNewBill(prev => ({ ...prev, subtotal: e.target.value }))}
                        className="w-full pl-8 pr-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest">VAT Amount</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">
                        {org.currency === 'GBP' ? '£' : org.currency === 'USD' ? '$' : '€'}
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        value={newBill.vatTotal}
                        onChange={(e) => setNewBill(prev => ({ ...prev, vatTotal: e.target.value }))}
                        className="w-full pl-8 pr-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowAdd(false)}
                    className="flex-1 px-6 py-4 bg-slate-50 text-slate-600 rounded-2xl font-bold hover:bg-slate-100 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95"
                  >
                    Save Bill
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
