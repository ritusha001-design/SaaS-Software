import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, getDocs, addDoc, orderBy, serverTimestamp } from 'firebase/firestore';
import { Organization, Invoice, Client } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import { Plus, Search, Filter, MoreHorizontal, Download, Mail, CheckCircle2, Clock, AlertCircle, FileText } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface InvoicesProps {
  org: Organization;
}

export default function Invoices({ org }: InvoicesProps) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showQuickAddClient, setShowQuickAddClient] = useState(false);
  
  // Create form state
  const [newInvoice, setNewInvoice] = useState({
    clientId: '',
    invoiceNumber: '',
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    items: [{ description: '', quantity: 1, unitPrice: 0 }],
    notes: ''
  });

  const [quickClient, setQuickClient] = useState({
    name: '',
    email: '',
    address: ''
  });

  useEffect(() => {
    fetchInvoices();
    fetchClients();
  }, [org.id]);

  const fetchInvoices = async () => {
    setLoading(true);
    const path = `organizations/${org.id}/invoices`;
    try {
      const q = query(
        collection(db, 'organizations', org.id, 'invoices'),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);
      setInvoices(snap.docs.map(d => ({ id: d.id, ...d.data() } as Invoice)));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, path);
    } finally {
      setLoading(false);
    }
  };

  const fetchClients = async () => {
    const snap = await getDocs(collection(db, 'organizations', org.id, 'clients'));
    setClients(snap.docs.map(d => ({ id: d.id, ...d.data() } as Client)));
  };

  const handleQuickAddClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickClient.name) return;

    try {
      const docRef = await addDoc(collection(db, 'organizations', org.id, 'clients'), {
        orgId: org.id,
        name: quickClient.name,
        email: quickClient.email,
        address: quickClient.address,
        createdAt: serverTimestamp()
      });
      
      const newClientObj = { id: docRef.id, ...quickClient, orgId: org.id } as Client;
      setClients([...clients, newClientObj]);
      setNewInvoice({ ...newInvoice, clientId: docRef.id });
      setShowQuickAddClient(false);
      setQuickClient({ name: '', email: '', address: '' });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `organizations/${org.id}/clients`);
    }
  };

  const calculateTotals = () => {
    const subtotal = newInvoice.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
    const vatTotal = subtotal * (org.vatRate / 100);
    return { subtotal, vatTotal, total: subtotal + vatTotal };
  };

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    const { subtotal, vatTotal, total } = calculateTotals();
    const path = `organizations/${org.id}/invoices`;
    
    try {
      const invData = {
        orgId: org.id,
        clientId: newInvoice.clientId,
        invoiceNumber: newInvoice.invoiceNumber || `INV-${Math.floor(Math.random() * 10000)}`,
        issueDate: newInvoice.issueDate,
        dueDate: newInvoice.dueDate,
        currency: org.currency,
        status: 'draft',
        subtotal,
        vatTotal,
        total,
        notes: newInvoice.notes,
        createdAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'organizations', org.id, 'invoices'), invData);
      
      // Add items as subcollection
      for (const item of newInvoice.items) {
        const itemPath = `organizations/${org.id}/invoices/${docRef.id}/items`;
        try {
          await addDoc(collection(db, 'organizations', org.id, 'invoices', docRef.id, 'items'), {
            ...item,
            vatRate: org.vatRate,
            total: item.quantity * item.unitPrice * (1 + org.vatRate / 100)
          });
        } catch (itemErr) {
          handleFirestoreError(itemErr, OperationType.CREATE, itemPath);
        }
      }

      setShowCreate(false);
      fetchInvoices();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const handleDownload = async (invoice: Invoice) => {
    try {
      const client = clients.find(c => c.id === invoice.clientId);
      const itemsSnap = await getDocs(collection(db, 'organizations', org.id, 'invoices', invoice.id, 'items'));
      const items = itemsSnap.docs.map(d => d.data());

      const res = await fetch('/api/invoices/pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoice, org, client, items })
      });

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Invoice-${invoice.invoiceNumber}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
      alert('Failed to download PDF');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle2 className="text-emerald-500" size={16} />;
      case 'sent': return <Clock className="text-blue-500" size={16} />;
      case 'overdue': return <AlertCircle className="text-rose-500" size={16} />;
      default: return <Clock className="text-slate-400" size={16} />;
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      case 'sent': return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'overdue': return 'bg-rose-50 text-rose-700 border-rose-100';
      default: return 'bg-slate-50 text-slate-700 border-slate-100';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search invoices..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
          />
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">
            <Filter size={16} />
            <span>Filter</span>
          </button>
          <button 
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 active:scale-95"
          >
            <Plus size={16} />
            <span>Create Invoice</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-100">
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Invoice</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Client</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Amount</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Due Date</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading ? (
              [...Array(5)].map((_, i) => (
                <tr key={i} className="animate-pulse">
                  <td colSpan={6} className="px-6 py-4 h-16 bg-slate-50/20" />
                </tr>
              ))
            ) : invoices.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                  <div className="flex flex-col items-center">
                    <FileText size={48} strokeWidth={1} className="mb-4 text-slate-300" />
                    <p className="font-medium">No invoices found</p>
                    <p className="text-xs">Create your first invoice to get started</p>
                  </div>
                </td>
              </tr>
            ) : (
              invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <span className="text-sm font-bold text-slate-900">#{inv.invoiceNumber}</span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {clients.find(c => c.id === inv.clientId)?.name || 'Unknown Client'}
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-bold text-slate-900">{formatCurrency(inv.total, inv.currency)}</span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {new Date(inv.dueDate).toLocaleDateString('en-GB')}
                  </td>
                  <td className="px-6 py-4">
                    <div className={cn(
                      "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] font-bold uppercase tracking-wider",
                      getStatusClass(inv.status)
                    )}>
                      {getStatusIcon(inv.status)}
                      {inv.status}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleDownload(inv)}
                        className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Download size={16} />
                      </button>
                      <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                        <Mail size={16} />
                      </button>
                      <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                        <MoreHorizontal size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Create Invoice Modal */}
      <AnimatePresence>
        {showCreate && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreate(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-slate-900">New Invoice</h3>
                <button onClick={() => setShowCreate(false)} className="text-slate-400 hover:text-slate-600">
                  <Plus size={24} className="rotate-45" />
                </button>
              </div>

              <form onSubmit={handleCreateInvoice} className="flex-1 overflow-y-auto p-8 space-y-8">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-slate-700">Client</label>
                      <button 
                        type="button"
                        onClick={() => setShowQuickAddClient(!showQuickAddClient)}
                        className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline flex items-center gap-1"
                      >
                        {showQuickAddClient ? 'Cancel' : '+ Quick Add'}
                      </button>
                    </div>

                    {showQuickAddClient ? (
                      <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-100 space-y-3 animate-in fade-in slide-in-from-top-2">
                        <input 
                          type="text"
                          placeholder="Client Name"
                          required
                          value={quickClient.name}
                          onChange={(e) => setQuickClient({...quickClient, name: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs border border-blue-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                        />
                        <input 
                          type="email"
                          placeholder="Email (optional)"
                          value={quickClient.email}
                          onChange={(e) => setQuickClient({...quickClient, email: e.target.value})}
                          className="w-full px-3 py-1.5 text-xs border border-blue-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                        />
                        <button 
                          type="button"
                          onClick={handleQuickAddClient}
                          disabled={!quickClient.name}
                          className="w-full py-2 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-blue-700 transition-colors disabled:opacity-50"
                        >
                          Create & Select Client
                        </button>
                      </div>
                    ) : (
                      <select 
                        required
                        value={newInvoice.clientId}
                        onChange={(e) => setNewInvoice({...newInvoice, clientId: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      >
                        <option value="">Select a client</option>
                        {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    )}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Invoice Number</label>
                    <input 
                      type="text"
                      placeholder="e.g. INV-1001"
                      value={newInvoice.invoiceNumber}
                      onChange={(e) => setNewInvoice({...newInvoice, invoiceNumber: e.target.value})}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Issue Date</label>
                    <input 
                      type="date"
                      value={newInvoice.issueDate}
                      onChange={(e) => setNewInvoice({...newInvoice, issueDate: e.target.value})}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Due Date</label>
                    <input 
                      type="date"
                      value={newInvoice.dueDate}
                      onChange={(e) => setNewInvoice({...newInvoice, dueDate: e.target.value})}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-slate-900">Items</h4>
                    <button 
                      type="button"
                      onClick={() => setNewInvoice({...newInvoice, items: [...newInvoice.items, { description: '', quantity: 1, unitPrice: 0 }]})}
                      className="text-xs font-bold text-blue-600 flex items-center gap-1 hover:underline"
                    >
                      <Plus size={14} />
                      Add Item
                    </button>
                  </div>
                  
                  <div className="space-y-3">
                    {newInvoice.items.map((item, index) => (
                      <div key={index} className="grid grid-cols-12 gap-3 items-end">
                        <div className="col-span-6 space-y-1">
                          <input 
                            placeholder="Description"
                            value={item.description}
                            onChange={(e) => {
                              const items = [...newInvoice.items];
                              items[index].description = e.target.value;
                              setNewInvoice({...newInvoice, items});
                            }}
                            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none"
                          />
                        </div>
                        <div className="col-span-2 space-y-1">
                          <input 
                            type="number"
                            placeholder="Qty"
                            value={item.quantity}
                            onChange={(e) => {
                              const items = [...newInvoice.items];
                              items[index].quantity = Number(e.target.value);
                              setNewInvoice({...newInvoice, items});
                            }}
                            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none"
                          />
                        </div>
                        <div className="col-span-3 space-y-1">
                          <input 
                            type="number"
                            placeholder="Price"
                            value={item.unitPrice}
                            onChange={(e) => {
                              const items = [...newInvoice.items];
                              items[index].unitPrice = Number(e.target.value);
                              setNewInvoice({...newInvoice, items});
                            }}
                            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none"
                          />
                        </div>
                        <div className="col-span-1 p-2 flex justify-center">
                           <button 
                             type="button" 
                             onClick={() => {
                               const items = newInvoice.items.filter((_, i) => i !== index);
                               setNewInvoice({...newInvoice, items});
                             }}
                             className="text-slate-400 hover:text-red-500"
                           >
                             <Plus size={16} className="rotate-45" />
                           </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl space-y-2">
                  <div className="flex justify-between text-sm text-slate-600">
                    <span>Subtotal</span>
                    <span>{formatCurrency(calculateTotals().subtotal, org.currency)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-slate-600">
                    <span>VAT ({org.vatRate}%)</span>
                    <span>{formatCurrency(calculateTotals().vatTotal, org.currency)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold text-slate-900 border-t border-slate-200 pt-2 mt-2">
                    <span>Total</span>
                    <span>{formatCurrency(calculateTotals().total, org.currency)}</span>
                  </div>
                </div>
              </form>

              <div className="px-8 py-6 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-4">
                <button 
                  onClick={() => setShowCreate(false)}
                  className="px-6 py-2 text-sm font-bold text-slate-600 hover:text-slate-900 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleCreateInvoice}
                  className="px-8 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                >
                  Save Invoice
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
