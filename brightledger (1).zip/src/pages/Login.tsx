import { useState } from 'react';
import { signInWithGoogle } from '../lib/firebase';
import { FileText } from 'lucide-react';
import { motion } from 'motion/react';
import { FirebaseError } from 'firebase/app';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithGoogle();
    } catch (err) {
      console.error('Login Error:', err);
      const firebaseError = err as FirebaseError;
      if (firebaseError.code === 'auth/popup-blocked') {
        setError('Login popup was blocked by your browser. Please allow popups for this site.');
      } else if (firebaseError.code === 'auth/popup-closed-by-user') {
        setError('Login was cancelled. Please try again.');
      } else if (firebaseError.code === 'auth/unauthorised-domain') {
        setError('This domain is not authorised for Google Login. Please check Firebase settings.');
      } else {
        setError('Login failed. IMPORTANT: Please click the "Open in new tab" icon in the top-right corner of this preview, then try logging in from there. Browser security often blocks login popups inside iframes.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-0 pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-indigo-50 rounded-full blur-3xl opacity-50" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-slate-100 rounded-full blur-3xl opacity-50" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-slate-200 overflow-hidden relative z-10"
      >
        <div className="p-10 text-center border-b border-slate-100 bg-linear-to-b from-slate-50/50 to-white">
          <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-6 shadow-xl shadow-indigo-100 transform -rotate-3">
            <FileText size={28} />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight mb-2">BrightLedger</h1>
          <p className="text-slate-500 font-medium">Accounting software for modern teams</p>
        </div>

        <div className="p-10">
          <div className="space-y-8">
            <div className="space-y-4">
              <button
                onClick={handleLogin}
                disabled={loading}
                className="w-full flex items-center justify-center gap-3 bg-white border border-slate-200 px-6 py-4 rounded-xl font-semibold text-slate-700 hover:bg-slate-50 hover:border-indigo-200 hover:text-indigo-600 transition-all active:scale-[0.98] disabled:opacity-50 shadow-sm"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                    <span>Sign in with Google</span>
                  </>
                )}
              </button>
            </div>

            {error && (
              <div className="p-4 bg-rose-50 text-rose-600 text-sm rounded-xl text-center border border-rose-100 font-medium">
                {error}
              </div>
            )}

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-100"></div>
              </div>
              <div className="relative flex justify-center text-xs font-bold uppercase tracking-widest text-slate-400">
                <span className="bg-white px-4">Trusted features</span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-5 text-left">
              {[
                { title: 'MTD Compliance', desc: 'Secure architecture for HMRC reporting.' },
                { title: 'VAT Engine', desc: 'Precise UK VAT handling out of the box.' },
                { title: 'AI Automation', desc: 'Intelligent reconciliation & categorization.' }
              ].map((feature, i) => (
                <div key={i} className="flex gap-4 items-start group">
                  <div className="mt-1 w-2 h-2 rounded-full bg-indigo-500 ring-4 ring-indigo-50 group-hover:bg-indigo-600 transition-all" />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 leading-none mb-1">{feature.title}</h3>
                    <p className="text-xs text-slate-500 font-medium">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-8 bg-slate-50/50 text-center border-t border-slate-100">
          <p className="text-xs text-slate-400 font-medium">
            By signing in, you agree to our <a href="#" className="text-indigo-600 hover:underline">Terms of Service</a> and <a href="#" className="text-indigo-600 hover:underline">Privacy Policy</a>.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
