import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, getDocs, limit, orderBy } from 'firebase/firestore';
import { Organization, Invoice, Expense } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  ArrowRight,
  Plus,
  Zap,
  Landmark,
  PieChart as PieIcon,
  BarChart2,
  AlertCircle
} from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

interface DashboardProps {
  org: Organization;
}

export default function Dashboard({ org }: DashboardProps) {
  const [stats, setStats] = useState({
    totalInvoiced: 0,
    unpaidAmount: 0,
    overdueAmount: 0,
    totalExpenses: 0,
  });
  const [recentInvoices, setRecentInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const invPath = `organizations/${org.id}/invoices`;
      const expPath = `organizations/${org.id}/expenses`;
      
      try {
        const invoicesQ = query(collection(db, 'organizations', org.id, 'invoices'));
        const expensesQ = query(collection(db, 'organizations', org.id, 'expenses'));
        
        const [invoicesSnap, expensesSnap] = await Promise.all([
          getDocs(invoicesQ).catch(e => {
            handleFirestoreError(e, OperationType.LIST, invPath);
            return null;
          }),
          getDocs(expensesQ).catch(e => {
            handleFirestoreError(e, OperationType.LIST, expPath);
            return null;
          })
        ]);

        let invoiced = 0;
        let unpaid = 0;
        let overdue = 0;
        const now = new Date().toISOString();

        if (invoicesSnap) {
          invoicesSnap.forEach((doc) => {
            const inv = doc.data() as Invoice;
            invoiced += inv.total;
            if (inv.status === 'sent' || inv.status === 'overdue') {
              unpaid += inv.total;
              if (inv.dueDate < now) overdue += inv.total;
            }
          });
        }

        let expenses = 0;
        if (expensesSnap) {
          expensesSnap.forEach((doc) => {
            expenses += (doc.data() as Expense).amount;
          });
        }

        setStats({
          totalInvoiced: invoiced,
          unpaidAmount: unpaid,
          overdueAmount: overdue,
          totalExpenses: expenses,
        });

        const recentQ = query(
          collection(db, 'organizations', org.id, 'invoices'),
          orderBy('createdAt', 'desc'),
          limit(5)
        );
        const recentSnap = await getDocs(recentQ).catch(e => {
          handleFirestoreError(e, OperationType.LIST, invPath);
          return null;
        });

        if (recentSnap) {
          setRecentInvoices(recentSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Invoice)));
        }

      } catch (err) {
        console.error("Dashboard error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [org.id]);

  const cards = [
    { 
      title: 'Total Revenue', 
      amount: stats.totalInvoiced, 
      icon: TrendingUp, 
      color: 'emerald',
      trend: '+12.5%',
    },
    { 
      title: 'Unpaid Invoices', 
      amount: stats.unpaidAmount, 
      icon: Clock, 
      color: 'amber',
      trend: `${recentInvoices.filter(i => i.status === 'sent').length} pending`,
    },
    { 
      title: 'Total Expenses', 
      amount: stats.totalExpenses, 
      icon: TrendingDown, 
      color: 'rose',
      trend: '-2.4%',
    },
  ];

  return (
    <div className="space-y-10 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Welcome Banner */}
      <section className="relative overflow-hidden bg-slate-900 rounded-[40px] p-10 text-white shadow-2xl shadow-slate-200">
        <div className="absolute top-0 right-0 p-12 text-white/5 pointer-events-none transform rotate-12 -mr-12 -mt-12">
          <Zap size={240} />
        </div>
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest mb-6 border border-white/10">
            <Zap size={12} className="text-amber-400" />
            Financial Intelligence Active
          </div>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-4 leading-tight">
            Hello, {org.name.split(' ')[0]} 👋
          </h1>
          <p className="text-slate-400 text-lg font-medium leading-relaxed mb-8">
            Your finances are in great shape today. You have <span className="text-emerald-400 font-bold">{formatCurrency(stats.totalInvoiced - stats.totalExpenses, org.currency)}</span> in net profit this fiscal segment.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link 
              to="/invoices" 
              className="px-6 py-3 bg-white text-slate-900 rounded-xl font-bold hover:bg-slate-100 transition-all active:scale-95 flex items-center gap-2 shadow-xl shadow-white/5"
            >
              <Plus size={18} />
              New Invoice
            </Link>
            <Link 
              to="/reports" 
              className="px-6 py-3 bg-white/10 backdrop-blur-md text-white rounded-xl font-bold hover:bg-white/20 transition-all border border-white/10 flex items-center gap-2"
            >
              <BarChart2 size={18} />
              View Reports
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {cards.map((card, i) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="group relative bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-slate-100 hover:-translate-y-1 transition-all cursor-pointer overflow-hidden"
          >
            <div className="relative">
              <div className="flex items-center justify-between mb-8">
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110",
                  card.color === 'emerald' ? "bg-emerald-50 text-emerald-600" :
                  card.color === 'amber' ? "bg-amber-50 text-amber-600" :
                  "bg-rose-50 text-rose-600"
                )}>
                  <card.icon size={24} />
                </div>
                <span className={cn(
                  "text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full border",
                  card.color === 'emerald' ? "bg-emerald-50 text-emerald-700 border-emerald-100" :
                  card.color === 'amber' ? "bg-amber-50 text-amber-700 border-amber-100" :
                  "bg-rose-50 text-rose-700 border-rose-100"
                )}>
                  {card.trend}
                </span>
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1.5">{card.title}</p>
              <p className="text-3xl font-black text-slate-900 tracking-tight">
                {formatCurrency(card.amount, org.currency)}
              </p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Recent Activity */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Financial Timeline</h2>
            <div className="flex gap-2">
               <button className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-[10px] font-black uppercase tracking-widest text-slate-500 hover:border-slate-300 transition-colors">
                 Invoices
               </button>
               <button className="px-3 py-1.5 bg-slate-50 border border-transparent rounded-lg text-[10px] font-black uppercase tracking-widest text-slate-400 hover:bg-slate-100 transition-colors">
                 Transactions
               </button>
            </div>
          </div>
          
          <div className="bg-white rounded-[32px] border border-slate-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50/50">
                    <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Entry Detail</th>
                    <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Type / Status</th>
                    <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {loading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="animate-pulse">
                        <td className="px-8 py-6"><div className="h-4 bg-slate-100 rounded w-48"></div></td>
                        <td className="px-8 py-6"><div className="h-6 bg-slate-100 rounded-full w-20"></div></td>
                        <td className="px-8 py-6"><div className="h-4 bg-slate-100 rounded w-24 ml-auto"></div></td>
                      </tr>
                    ))
                  ) : recentInvoices.length === 0 ? (
                    <tr>
                      <td colSpan={3} className="px-8 py-20 text-center">
                        <div className="flex flex-col items-center gap-3">
                          <div className="w-16 h-16 rounded-full bg-slate-50 flex items-center justify-center text-slate-300">
                            <Clock size={32} />
                          </div>
                          <p className="text-slate-500 font-medium tracking-tight text-lg">No recent activity detected</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    recentInvoices.map((inv) => (
                      <tr key={inv.id} className="hover:bg-slate-50/50 transition-colors group cursor-pointer">
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                              <Landmark size={18} />
                            </div>
                            <div className="flex flex-col">
                              <span className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">#{inv.invoiceNumber} • {inv.clientId}</span>
                              <span className="text-[10px] font-bold text-slate-400 mt-0.5 tracking-widest uppercase">{inv.createdAt ? new Date(inv.createdAt as unknown as string).toLocaleDateString() : 'Just now'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6 text-sm">
                          <span className={cn(
                            "inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border",
                            inv.status === 'paid' ? "bg-emerald-50 text-emerald-600 border-emerald-100" :
                            inv.status === 'sent' ? "bg-indigo-50 text-indigo-600 border-indigo-100" :
                            "bg-slate-50 text-slate-500 border-slate-100"
                          )}>
                            {inv.status}
                          </span>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <span className="text-sm font-black text-slate-900">{formatCurrency(inv.total, org.currency)}</span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            
            <div className="p-8 bg-slate-50/50 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Fiscal Year Progress</span>
                  <div className="flex items-center gap-3">
                    <div className="w-32 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: '45%' }}></div>
                    </div>
                    <span className="text-xs font-black text-slate-900">45%</span>
                  </div>
                </div>
                <div className="w-px h-8 bg-slate-200" />
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Avg Pay Cycle</span>
                  <p className="text-sm font-black text-slate-900">12.4 Days</p>
                </div>
              </div>
              <button className="flex items-center gap-2 text-xs font-black text-indigo-600 hover:text-indigo-700 transition-colors uppercase tracking-widest">
                Full Audit Trail <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Quick Insights & Actions */}
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Intelligence</h2>
            <Zap size={20} className="text-amber-400 animate-pulse" />
          </div>
          
          <div className="bg-slate-900 rounded-[32px] p-8 text-white space-y-8 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 text-white/5 opacity-0 group-hover:opacity-10 transition-opacity">
              <PieIcon size={120} />
            </div>
            
            <div className="space-y-2 relative">
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Projected Run Rate</span>
              <div className="flex items-end justify-between gap-4">
                <p className="text-3xl font-black text-emerald-400">{formatCurrency(stats.totalInvoiced * 12, org.currency)}</p>
                <div className="flex flex-col items-end">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Annual Forecast</span>
                  <div className="w-16 h-1 mt-2 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500" style={{ width: '82%' }}></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 relative">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors cursor-pointer group/card">
                <p className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-1 group-hover/card:text-indigo-400">Next VAT Due</p>
                <p className="text-lg font-black text-white">15 Jul</p>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors cursor-pointer group/card">
                <p className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-1 group-hover/card:text-rose-400">Burn Rate</p>
                <p className="text-lg font-black text-emerald-400">Stable</p>
              </div>
            </div>

            <div className="pt-4 relative border-t border-white/5">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Action Center</p>
              <div className="space-y-3">
                <button className="w-full flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-indigo-600 transition-all text-left group/action">
                  <div className="flex flex-col">
                    <span className="text-xs font-black text-white">Identify Savings</span>
                    <span className="text-[10px] font-bold text-slate-400 group-hover/action:text-indigo-100 uppercase tracking-widest mt-0.5">3 Potential Reductions</span>
                  </div>
                  <ArrowRight size={16} className="text-slate-500 group-hover/action:text-white" />
                </button>
                <button className="w-full flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-indigo-600 transition-all text-left group/action">
                  <div className="flex flex-col">
                    <span className="text-xs font-black text-white">Chase Overdue</span>
                    <span className="text-[10px] font-bold text-slate-400 group-hover/action:text-indigo-100 uppercase tracking-widest mt-0.5">5 Invoices Need Following Up</span>
                  </div>
                  <ArrowRight size={16} className="text-slate-500 group-hover/action:text-white" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4 group cursor-pointer hover:border-indigo-100 transition-all">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600 group-hover:scale-110 transition-transform">
              <AlertCircle size={24} />
            </div>
            <div>
              <p className="text-sm font-black text-slate-900">Tax Deadline</p>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Self-Assessment due in 14 days</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
