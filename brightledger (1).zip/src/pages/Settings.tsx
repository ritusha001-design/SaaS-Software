import React, { useState } from 'react';
import { db } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { Organization } from '../types';
import { Save, Building, Shield, Bell, CreditCard } from 'lucide-react';
import { cn } from '../lib/utils';

interface SettingsProps {
  org: Organization;
  onUpdate: (updated: Organization) => void;
}

export default function Settings({ org, onUpdate }: SettingsProps) {
  const [formData, setFormData] = useState({
    name: org.name,
    address: org.address || '',
    taxId: org.taxId || '',
    currency: org.currency,
    vatRate: org.vatRate,
    vatRegistered: org.vatRegistered
  });
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('general');

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateDoc(doc(db, 'organizations', org.id), formData);
      onUpdate({ ...org, ...formData });
      alert('Settings updated successfully!');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'general', name: 'General', icon: Building },
    { id: 'billing', name: 'Billing', icon: CreditCard },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'notifications', name: 'Notifications', icon: Bell },
  ];

  return (
    <div className="flex flex-col lg:flex-row gap-10">
      {/* Sidebar Navigation */}
      <div className="lg:w-72 space-y-2">
        <div className="mb-6 px-4">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Settings</h2>
          <p className="text-sm text-slate-500 font-medium">Manage your organization</p>
        </div>
        <div className="p-2 bg-white rounded-2xl border border-slate-200">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200",
                activeTab === tab.id 
                  ? "bg-indigo-50 text-indigo-700 shadow-sm shadow-indigo-100/50" 
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              )}
            >
              <div className={cn(
                "p-1.5 rounded-lg transition-colors",
                activeTab === tab.id ? "bg-indigo-100 text-indigo-700" : "bg-slate-100 text-slate-400 group-hover:bg-slate-200"
              )}>
                <tab.icon size={18} />
              </div>
              <span>{tab.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-[0_8px_30px_rgb(0,0,0,0.02)] overflow-hidden">
        {activeTab === 'general' && (
          <form onSubmit={handleUpdate}>
            <div className="p-8 lg:p-10">
              <div className="flex items-center justify-between mb-10 pb-6 border-b border-slate-100">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 tracking-tight">Business Profile</h3>
                  <p className="text-slate-500 font-medium text-sm mt-1">Configure your official company information.</p>
                </div>
                <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                  <Building size={24} />
                </div>
              </div>
              
              <div className="space-y-8">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Legal Entity Name</label>
                  <input 
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium shadow-sm"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Registered Address</label>
                  <textarea 
                    rows={3}
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium shadow-sm resize-none"
                    placeholder="Enter your full business address..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Default Currency</label>
                    <select 
                      value={formData.currency}
                      onChange={(e) => setFormData({...formData, currency: e.target.value as 'GBP' | 'USD' | 'EUR'})}
                      className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium shadow-sm appearance-none cursor-pointer"
                    >
                      <option value="GBP">GBP (£) - British Pound</option>
                      <option value="USD">USD ($) - US Dollar</option>
                      <option value="EUR">EUR (€) - Euro</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Tax / Company Number</label>
                    <input 
                      type="text"
                      value={formData.taxId}
                      onChange={(e) => setFormData({...formData, taxId: e.target.value})}
                      className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium shadow-sm"
                      placeholder="e.g. 12345678"
                    />
                  </div>
                </div>
                
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex items-start gap-4">
                  <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl mt-1">
                    <Shield size={20} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-bold text-slate-900">MTD & VAT Compliance</p>
                      <input 
                        type="checkbox"
                        checked={formData.vatRegistered}
                        onChange={(e) => setFormData({...formData, vatRegistered: e.target.checked})}
                        className="w-6 h-6 rounded-lg border-2 border-slate-300 text-indigo-600 focus:ring-offset-0 focus:ring-indigo-500 cursor-pointer checked:bg-indigo-600 appearance-none bg-white checked:after:content-['✓'] checked:after:text-white checked:after:flex checked:after:items-center checked:after:justify-center transition-all"
                      />
                    </div>
                    <p className="text-xs text-slate-500 font-medium mt-1">Enable automatic VAT calculation and digital record keeping for HMRC compliance.</p>
                  </div>
                </div>

                {formData.vatRegistered && (
                  <div className="space-y-2 animate-in fade-in slide-in-from-top-4">
                    <label className="text-sm font-bold text-slate-700 ml-1">Default Standard VAT Rate (%)</label>
                    <div className="relative">
                      <input 
                        type="number"
                        value={formData.vatRate}
                        onChange={(e) => setFormData({...formData, vatRate: Number(e.target.value)})}
                        className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium shadow-sm"
                      />
                      <span className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">%</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-8 lg:p-10 bg-slate-50 flex justify-end border-t border-slate-100">
              <button 
                type="submit"
                disabled={loading}
                className="flex items-center gap-3 px-10 py-5 bg-indigo-600 text-white rounded-2xl text-lg font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 disabled:opacity-50 active:scale-[0.98]"
              >
                {loading ? (
                  <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Save size={20} />
                    <span>Save Preferences</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {activeTab !== 'general' && (
          <div className="p-20 text-center space-y-6">
             <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mx-auto text-indigo-300 ring-8 ring-indigo-50/50">
                <Shield size={48} />
             </div>
             <div>
                <h3 className="text-2xl font-bold text-slate-900 tracking-tight">Security & Billing</h3>
                <p className="text-slate-500 font-medium max-w-sm mx-auto mt-2">These features are currently being refined to meet our high security standards. Check back soon for updates.</p>
             </div>
             <div className="pt-4">
                <button 
                  onClick={() => setActiveTab('general')}
                  className="text-indigo-600 font-bold hover:text-indigo-700 transition-colors"
                >
                  Return to General Settings
                </button>
             </div>
          </div>
        )}
      </div>
    </div>
  );
}
