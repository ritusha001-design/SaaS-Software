import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, getDocs, orderBy } from 'firebase/firestore';
import { Organization, Invoice, Expense, Bill, VatRecord } from '../types';
import { BarChart3, PieChart, Download, FileText, Calendar, CheckSquare } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';

interface ReportsProps {
  org: Organization;
}

export default function Reports({ org }: ReportsProps) {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({
    invoices: [] as Invoice[],
    expenses: [] as Expense[],
    bills: [] as Bill[],
    vatRecords: [] as VatRecord[]
  });

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [invoicesSnap, expensesSnap, billsSnap, vatSnap] = await Promise.all([
          getDocs(query(collection(db, 'organizations', org.id, 'invoices'))),
          getDocs(query(collection(db, 'organizations', org.id, 'expenses'))),
          getDocs(query(collection(db, 'organizations', org.id, 'bills'))),
          getDocs(query(collection(db, 'organizations', org.id, 'vat_records'), orderBy('periodEnd', 'desc')))
        ]);

        setData({
          invoices: invoicesSnap.docs.map(d => ({ id: d.id, ...d.data() } as Invoice)),
          expenses: expensesSnap.docs.map(d => ({ id: d.id, ...d.data() } as Expense)),
          bills: billsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Bill)),
          vatRecords: vatSnap.docs.map(d => ({ id: d.id, ...d.data() } as VatRecord))
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [org.id]);

  const totalSales = data.invoices.filter(i => i.status !== 'draft' && i.status !== 'void').reduce((acc, i) => acc + i.subtotal, 0);
  const totalPurchases = data.expenses.reduce((acc, e) => acc + (e.amount - e.vatAmount), 0) + data.bills.reduce((acc, b) => acc + b.subtotal, 0);
  const grossProfit = totalSales - totalPurchases;

  const totalSalesVat = data.invoices.filter(i => i.status !== 'draft' && i.status !== 'void').reduce((acc, i) => acc + i.vatTotal, 0);
  const totalPurchaseVat = data.expenses.reduce((acc, e) => acc + e.vatAmount, 0) + data.bills.reduce((acc, b) => acc + b.vatTotal, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-500 font-bold animate-pulse uppercase tracking-widest text-[10px]">Processing Intelligence...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <BarChart3 className="text-indigo-600" />
            Financial Intelligence
          </h1>
          <p className="text-slate-500 font-medium mt-1">SaaS-grade analytics for your business performance</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 font-bold transition-all border border-slate-200 rounded-xl bg-white shadow-sm hover:shadow-md active:scale-95">
            <Calendar size={18} />
            <span>Last Quarter</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95">
            <Download size={18} />
            <span>Export Data</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profit & Loss Mini Card */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 text-slate-50/50 -mr-4 -mt-4 transform rotate-12 transition-transform group-hover:rotate-6">
              <PieChart size={160} />
            </div>
            
            <div className="relative">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                  <BarChart3 size={20} />
                </div>
                <h3 className="text-xl font-black text-slate-900 tracking-tight">Executive Summary</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="space-y-1">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Sales (Net)</span>
                  <p className="text-2xl font-black text-slate-900">{formatCurrency(totalSales, org.currency)}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Expenses (Net)</span>
                  <p className="text-2xl font-black text-slate-900">{formatCurrency(totalPurchases, org.currency)}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Gross Profit</span>
                  <p className={cn("text-2xl font-black", grossProfit >= 0 ? "text-emerald-600" : "text-rose-600")}>
                    {formatCurrency(grossProfit, org.currency)}
                  </p>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t border-slate-50 grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-slate-600">Net Profit Margin</span>
                    <span className="text-sm font-black text-indigo-600">{totalSales ? ((grossProfit / totalSales) * 100).toFixed(1) : 0}%</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-500 rounded-full" 
                      style={{ width: `${totalSales ? Math.max(0, Math.min(100, (grossProfit / totalSales) * 100)) : 0}%` }}
                    ></div>
                  </div>
                </div>
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-slate-600">Expense Ratio</span>
                    <span className="text-sm font-black text-rose-600">{totalSales ? ((totalPurchases / totalSales) * 100).toFixed(1) : 0}%</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-rose-500 rounded-full" 
                      style={{ width: `${totalSales ? Math.max(0, Math.min(100, (totalPurchases / totalSales) * 100)) : 0}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer hover:border-indigo-200 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                  <FileText size={24} />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">Profit & Loss Report</p>
                  <p className="text-xs text-slate-400">Detailed breakdown for current fiscal year</p>
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer hover:border-indigo-200 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                  <CheckSquare size={24} />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">Balance Sheet</p>
                  <p className="text-xs text-slate-400">Snapshot of assets and liabilities</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* VAT / Tax Panel */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-black text-slate-900">VAT Summary</h3>
              <div className="px-3 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase tracking-widest rounded-full">Quarterly</div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between group">
                <span className="text-sm font-medium text-slate-500">Output VAT (Sales)</span>
                <span className="text-sm font-black text-rose-500">{formatCurrency(totalSalesVat, org.currency)}</span>
              </div>
              <div className="flex items-center justify-between group">
                <span className="text-sm font-medium text-slate-500">Input VAT (Purchases)</span>
                <span className="text-sm font-black text-emerald-500">{formatCurrency(totalPurchaseVat, org.currency)}</span>
              </div>
              <div className="h-px bg-slate-50 my-2" />
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900">Net {totalSalesVat - totalPurchaseVat >= 0 ? 'Payable' : 'Reclaimable'}</span>
                <span className={cn(
                  "text-lg font-black",
                  totalSalesVat - totalPurchaseVat >= 0 ? "text-rose-600" : "text-emerald-600"
                )}>
                  {formatCurrency(Math.abs(totalSalesVat - totalPurchaseVat), org.currency)}
                </span>
              </div>
            </div>

            <button className="w-full mt-8 py-3 px-4 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all active:scale-95">
              Submit VAT Return (MTD)
            </button>
          </div>

          <div className="bg-indigo-600 p-6 rounded-3xl text-white shadow-xl shadow-indigo-100 relative overflow-hidden group">
            <div className="absolute -right-4 -bottom-4 text-white/10 transform -rotate-12 transition-transform group-hover:rotate-0">
              <PieChart size={120} />
            </div>
            <div className="relative">
              <h4 className="text-sm font-bold opacity-80 mb-1">Estimated Tax Liability</h4>
              <p className="text-2xl font-black mb-4">{formatCurrency(grossProfit * 0.19, org.currency)}</p>
              <p className="text-[10px] font-bold opacity-60 uppercase tracking-widest leading-relaxed">Based on current UK Corp Tax Rate (19%) applied to YTD Net Profit.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
