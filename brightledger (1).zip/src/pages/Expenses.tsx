import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, getDocs, addDoc, orderBy, serverTimestamp } from 'firebase/firestore';
import { Organization, Expense } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import { Plus, Search, Receipt, Sparkles } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface ExpensesProps {
  org: Organization;
}

export default function Expenses({ org }: ExpensesProps) {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  const [newExpense, setNewExpense] = useState({
    description: '',
    amount: 0,
    category: 'Miscellaneous',
    date: new Date().toISOString().split('T')[0],
    supplier: ''
  });

  useEffect(() => {
    fetchExpenses();
  }, [org.id]);

  const fetchExpenses = async () => {
    setLoading(true);
    const path = `organizations/${org.id}/expenses`;
    try {
      const q = query(collection(db, 'organizations', org.id, 'expenses'), orderBy('date', 'desc'));
      const snap = await getDocs(q);
      setExpenses(snap.docs.map(d => ({ id: d.id, ...d.data() } as Expense)));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, path);
    } finally {
      setLoading(false);
    }
  };

  const handleAiCategorize = async () => {
    if (!newExpense.description) return;
    setAiLoading(true);
    try {
      const prompt = `Categorize this business expense description into one of these categories: 
      Software, Rent, Utilities, Salaries, Marketing, Travel, Entertainment, Office Supplies, Insurance, Professional Services, Miscellaneous.
      Description: "${newExpense.description}"
      Return ONLY the category name.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: prompt,
      });

      const category = response.text?.trim();
      if (category) {
        setNewExpense({ ...newExpense, category });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const path = `organizations/${org.id}/expenses`;
    try {
      const data = {
        orgId: org.id,
        ...newExpense,
        vatAmount: newExpense.amount * (org.vatRate / 100),
        currency: org.currency,
        status: 'pending',
        createdAt: serverTimestamp()
      };
      await addDoc(collection(db, 'organizations', org.id, 'expenses'), data);
      setShowAdd(false);
      fetchExpenses();
      setNewExpense({
        description: '',
        amount: 0,
        category: 'Miscellaneous',
        date: new Date().toISOString().split('T')[0],
        supplier: ''
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search expenses..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
          />
        </div>
        <button 
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 active:scale-95"
        >
          <Plus size={16} />
          <span>Add Expense</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          [...Array(6)].map((_, i) => (
            <div key={i} className="h-32 bg-white rounded-2xl border border-slate-200 animate-pulse" />
          ))
        ) : expenses.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400">
            <Receipt size={48} strokeWidth={1} className="mx-auto mb-4 text-slate-300" />
            <p className="font-medium">No expenses recorded</p>
          </div>
        ) : (
          expenses.map((expense) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={expense.id} 
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm grow flex flex-col"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">{expense.category}</span>
                <span className="text-xs font-medium text-slate-500">{new Date(expense.date).toLocaleDateString('en-GB')}</span>
              </div>
              <h4 className="text-sm font-bold text-slate-900 mb-1 truncate">{expense.description}</h4>
              <p className="text-xs text-slate-500 mb-4">{expense.supplier || 'No supplier'}</p>
              <div className="mt-auto pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-lg font-bold text-slate-900">{formatCurrency(expense.amount, expense.currency)}</span>
                <div className={cn(
                  "w-2 h-2 rounded-full",
                  expense.status === 'cleared' ? 'bg-emerald-500' : 'bg-amber-500'
                )} />
              </div>
            </motion.div>
          ))
        )}
      </div>

      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdd(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden p-8"
            >
              <h3 className="text-xl font-bold text-slate-900 mb-6">Add New Expense</h3>
              
              <form onSubmit={handleAddExpense} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Description</label>
                  <div className="relative">
                    <input 
                      type="text"
                      required
                      value={newExpense.description}
                      onChange={(e) => setNewExpense({...newExpense, description: e.target.value})}
                      onBlur={handleAiCategorize}
                      placeholder="e.g. AWS Subscription"
                      className="w-full pl-4 pr-10 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                    <button 
                      type="button"
                      onClick={handleAiCategorize}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-blue-600 transition-colors"
                      title="AI Autocomplete Category"
                    >
                      <Sparkles size={18} className={aiLoading ? "animate-pulse text-blue-600" : ""} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Amount</label>
                    <input 
                      type="number"
                      required
                      value={newExpense.amount}
                      onChange={(e) => setNewExpense({...newExpense, amount: Number(e.target.value)})}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Date</label>
                    <input 
                      type="date"
                      required
                      value={newExpense.date}
                      onChange={(e) => setNewExpense({...newExpense, date: e.target.value})}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Category</label>
                  <select 
                    value={newExpense.category}
                    onChange={(e) => setNewExpense({...newExpense, category: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    {[ 'Software', 'Rent', 'Utilities', 'Salaries', 'Marketing', 'Travel', 'Entertainment', 'Office Supplies', 'Insurance', 'Professional Services', 'Miscellaneous'].map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Supplier (Optional)</label>
                  <input 
                    type="text"
                    value={newExpense.supplier}
                    onChange={(e) => setNewExpense({...newExpense, supplier: e.target.value})}
                    placeholder="e.g. Amazon"
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                <div className="pt-4 flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setShowAdd(false)}
                    className="flex-1 px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                  >
                    Save Expense
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
