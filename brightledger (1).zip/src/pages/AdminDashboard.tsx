import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, getDocs, limit } from 'firebase/firestore';
import { UserProfile, Organization } from '../types';
import { 
  Users, 
  Building2, 
  Zap, 
  Activity, 
  ShieldCheck, 
  CreditCard,
  TrendingUp,
  ArrowRight
} from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion } from 'motion/react';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalOrgs: 0,
    activeSubscriptions: 0,
    revenue: 0
  });
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'users' | 'organizations' | 'logs'>('users');

  useEffect(() => {
    const fetchAdminData = async () => {
      try {
        const usersSnap = await getDocs(query(collection(db, 'users'), limit(50)));
        const orgsSnap = await getDocs(query(collection(db, 'organizations'), limit(50)));

        const usersData = usersSnap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile));
        const orgsData = orgsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Organization));

        setUsers(usersData);
        setOrgs(orgsData);

        setStats({
          totalUsers: usersData.length,
          totalOrgs: orgsData.length,
          activeSubscriptions: orgsData.length, // Simplified
          revenue: orgsData.length * 15 // Mock calculation based on £15/mo plan
        });

      } catch (err) {
        console.error("Admin Dashboard error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchAdminData();
  }, []);

  const statCards = [
    { title: 'Total Customers', value: stats.totalUsers, icon: Users, color: 'indigo' },
    { title: 'Organizations', value: stats.totalOrgs, icon: Building2, color: 'emerald' },
    { title: 'Active Plans', value: stats.activeSubscriptions, icon: CreditCard, color: 'amber' },
    { title: 'Est. Monthly Revenue', value: formatCurrency(stats.revenue, 'GBP'), icon: TrendingUp, color: 'rose' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-500 font-bold animate-pulse uppercase tracking-widest text-[10px]">Accessing Secure Core...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Admin Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <ShieldCheck className="text-indigo-600" />
            System Administration
          </h1>
          <p className="text-slate-500 font-medium mt-1">Platform-wide oversight and monitoring</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:border-slate-300 transition-all shadow-sm">
            Download Global CSV
          </button>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
            System Health Check
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, i) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm"
          >
            <div className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-lg",
              card.color === 'indigo' ? "bg-indigo-50 text-indigo-600 shadow-indigo-50" :
              card.color === 'emerald' ? "bg-emerald-50 text-emerald-600 shadow-emerald-50" :
              card.color === 'amber' ? "bg-amber-50 text-amber-600 shadow-amber-50" :
              "bg-rose-50 text-rose-600 shadow-rose-50"
            )}>
              <card.icon size={22} />
            </div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">{card.title}</p>
            <p className="text-2xl font-black text-slate-900 tracking-tight">{card.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
        <div className="xl:col-span-2 space-y-6">
          <div className="flex items-center gap-6 border-b border-slate-200 pb-2">
            {[
              { id: 'users', label: 'Users', icon: Users },
              { id: 'organizations', label: 'Companies', icon: Building2 },
              { id: 'logs', label: 'Audit Logs', icon: Activity },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as 'users' | 'organizations' | 'logs')}
                className={cn(
                  "flex items-center gap-2 pb-2 text-sm font-bold transition-all relative",
                  activeTab === tab.id ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
                )}
              >
                <tab.icon size={16} />
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
                )}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-[32px] border border-slate-100 shadow-sm overflow-hidden min-h-[400px]">
            {activeTab === 'users' ? (
              <table className="w-full text-left">
                <thead className="bg-slate-50/50">
                  <tr>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">User Details</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Email</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Admin Status</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Created</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {users.map(u => (
                    <tr key={u.uid} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border border-slate-200">
                            {u.photoURL ? <img src={u.photoURL} alt="" className="w-full h-full object-cover" /> : <span className="text-[10px] font-bold text-slate-400">?</span>}
                          </div>
                          <span className="text-sm font-bold text-slate-900">{u.displayName || 'No Name'}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-slate-600">{u.email}</td>
                      <td className="px-6 py-4">
                        {u.isSuperAdmin ? (
                          <span className="px-2 py-1 bg-amber-50 text-amber-700 text-[8px] font-black uppercase tracking-widest rounded-full border border-amber-100">Super Admin</span>
                        ) : (
                          <span className="px-2 py-1 bg-slate-50 text-slate-500 text-[8px] font-black uppercase tracking-widest rounded-full border border-slate-100">Standard</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : activeTab === 'organizations' ? (
              <table className="w-full text-left">
                <thead className="bg-slate-50/50">
                  <tr>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Org Name</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Currency</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">VAT Status</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Created</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {orgs.map(o => (
                    <tr key={o.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                            <Building2 size={16} />
                          </div>
                          <span className="text-sm font-bold text-slate-900">{o.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-slate-600 uppercase">{o.currency}</td>
                      <td className="px-6 py-4">
                        {o.vatRegistered ? (
                          <span className="px-2 py-1 bg-emerald-50 text-emerald-700 text-[8px] font-black uppercase tracking-widest rounded-full border border-emerald-100">VAT Reg</span>
                        ) : (
                          <span className="px-2 py-1 bg-slate-50 text-slate-500 text-[8px] font-black uppercase tracking-widest rounded-full border border-slate-100">Non-VAT</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {o.createdAt ? new Date(o.createdAt).toLocaleDateString() : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-slate-400 opacity-50">
                <Activity size={48} className="mb-4" />
                <p className="font-bold uppercase tracking-widest text-xs">Live System Log Stream Inactive</p>
                <p className="text-[10px] mt-2">Connect to AWS/CloudWatch for real-time monitoring</p>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900 rounded-[32px] p-8 text-white">
            <h3 className="text-xl font-black mb-6 flex items-center gap-2">
              <Zap className="text-amber-400 animate-pulse" size={20} />
              Quick Analytics
            </h3>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-500">
                  <span>Usage Capacity</span>
                  <span className="text-white">82%</span>
                </div>
                <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                   <div className="h-full bg-indigo-500" style={{ width: '82%' }}></div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Renewal Rate</p>
                  <p className="text-xl font-black text-emerald-400">94.2%</p>
                </div>
                <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">New Orgs</p>
                  <p className="text-xl font-black text-indigo-400">+12%</p>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 space-y-3">
                <button className="w-full flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-all group">
                  <span className="text-xs font-bold">Billing Cycles</span>
                  <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="w-full flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-all group">
                  <span className="text-xs font-bold">Plan Configuration</span>
                  <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4 group cursor-pointer hover:border-indigo-100 transition-all">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600 group-hover:scale-110 transition-transform">
              <ShieldCheck size={24} />
            </div>
            <div>
              <p className="text-sm font-black text-slate-900">Security Audit</p>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Last Check: 2 hours ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
