import React, { useState } from 'react';
import { 
  Zap, 
  CheckCircle2, 
  ArrowRight, 
  BarChart3, 
  ShieldCheck, 
  Smartphone, 
  Mail, 
  MessageSquare,
  FileText,
  Wallet,
  PieChart
} from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';

interface NavItemProps {
  href: string;
  children: React.ReactNode;
}

const NavItem = ({ href, children }: NavItemProps) => (
  <a 
    href={href} 
    className="text-slate-600 hover:text-indigo-600 font-bold text-sm transition-colors"
  >
    {children}
  </a>
);

export default function Landing() {
  const [activePlan, setActivePlan] = useState<'monthly' | 'yearly'>('monthly');

  const plans = [
    {
      name: 'Starter',
      price: activePlan === 'monthly' ? '0' : '0',
      description: 'Perfect for freelancers just starting out.',
      features: [
        'Unlimited Invoicing',
        'Basic Expense Tracking',
        'Single User Access',
        'Standard Email Support',
        'VAT Calculation'
      ],
      cta: 'Get Started',
      popular: false
    },
    {
      name: 'Professional',
      price: activePlan === 'monthly' ? '15' : '12',
      description: 'Ideal for growing small businesses.',
      features: [
        'Everything in Starter',
        'Multi-currency Support',
        'Advanced Reports',
        'Stripe Integration',
        'Priority Support',
        'Receipt Scanning'
      ],
      cta: 'Start Free Trial',
      popular: true
    },
    {
      name: 'Enterprise',
      price: activePlan === 'monthly' ? '35' : '28',
      description: 'For businesses needing full accounting suite.',
      features: [
        'Everything in Professional',
        'Team Collaboration',
        'Custom Roles',
        'Dedicated Accountant Access',
        'API Access',
        'White-label Invoices'
      ],
      cta: 'Contact Sales',
      popular: false
    }
  ];

  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 overflow-x-hidden">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-10">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
                <Zap size={22} fill="currentColor" />
              </div>
              <span className="text-xl font-black tracking-tight text-slate-900 underline decoration-indigo-500 decoration-4 underline-offset-4">BrightLedger</span>
            </div>
            
            <nav className="hidden lg:flex items-center gap-8">
              <NavItem href="#home">Home</NavItem>
              <NavItem href="#about">What is BrightLedger?</NavItem>
              <NavItem href="#features">What Can it Do?</NavItem>
              <NavItem href="#pricing">Pricing</NavItem>
              <NavItem href="#contact">Contact</NavItem>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <Link to="/login" className="hidden sm:block text-sm font-bold text-slate-600 hover:text-slate-900 transition-colors">
              Sign In
            </Link>
            <Link 
              to="/login?signup=true" 
              className="hidden sm:block px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
            >
              Join Now
            </Link>
            
            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:bg-slate-50 rounded-xl transition-colors"
            >
              <div className="w-6 h-5 flex flex-col justify-between">
                <span className={cn("w-full h-0.5 bg-current transition-all", isMenuOpen && "rotate-45 translate-y-2")} />
                <span className={cn("w-full h-0.5 bg-current transition-all", isMenuOpen && "opacity-0")} />
                <span className={cn("w-full h-0.5 bg-current transition-all", isMenuOpen && "-rotate-45 -translate-y-2")} />
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <motion.div 
          initial={false}
          animate={{ height: isMenuOpen ? 'auto' : 0, opacity: isMenuOpen ? 1 : 0 }}
          className="lg:hidden overflow-hidden bg-white border-b border-slate-100"
        >
          <div className="p-6 space-y-4">
            <a href="#home" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-slate-900">Home</a>
            <a href="#about" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-slate-900">What is BrightLedger?</a>
            <a href="#features" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-slate-900">What Can it Do?</a>
            <a href="#pricing" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-slate-900">Pricing</a>
            <a href="#contact" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-slate-900">Contact</a>
            <div className="pt-4 flex flex-col gap-4">
              <Link to="/login" className="w-full py-4 text-center text-slate-900 font-bold border border-slate-200 rounded-xl">Sign In</Link>
              <Link to="/login?signup=true" className="w-full py-4 text-center text-white bg-indigo-600 font-bold rounded-xl">Join Now</Link>
            </div>
          </div>
        </motion.div>
      </header>

      {/* Hero Section */}
      <section id="home" className="pt-40 pb-20 px-6">
        <div className="max-w-7xl mx-auto text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-full text-xs font-black uppercase tracking-widest border border-indigo-100"
          >
            <Zap size={14} className="fill-current" />
            The Future of Small Business Accounting
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-black tracking-tight leading-[1.1] max-w-4xl mx-auto text-slate-900"
          >
            Keep your focus on <span className="text-indigo-600">Growth</span>, we'll handle the books.
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-slate-500 font-medium max-w-2xl mx-auto leading-relaxed"
          >
            BrightLedger is the world's most intuitive SaaS accounting platform. Designed for small teams and freelancers who hate spreadsheets.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
          >
            <Link to="/login?signup=true" className="w-full sm:w-auto px-10 py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-2xl shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 flex items-center justify-center gap-3 group">
              Start Free Trial 
              <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <a href="#features" className="w-full sm:w-auto px-10 py-5 bg-white text-slate-900 border-2 border-slate-100 rounded-2xl font-black text-lg hover:border-indigo-100 transition-all flex items-center justify-center gap-3">
              See How it Works
            </a>
          </motion.div>

          {/* Abstract Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="pt-20"
          >
            <div className="relative max-w-6xl mx-auto bg-slate-900 rounded-[48px] p-4 shadow-3xl">
              <div className="bg-white rounded-[32px] overflow-hidden border border-slate-100 shadow-inner">
                <img 
                  src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2426" 
                  alt="Dashboard Preview" 
                  className="w-full h-auto opacity-90"
                />
              </div>
              {/* Floating elements */}
              <div className="absolute -left-12 top-1/4 bg-white p-6 rounded-3xl shadow-2xl border border-slate-100 hidden xl:block">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                    <BarChart3 size={24} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Revenue Growth</p>
                    <p className="text-xl font-black text-slate-900">+42%</p>
                  </div>
                </div>
              </div>
              <div className="absolute -right-12 bottom-1/4 bg-white p-6 rounded-3xl shadow-2xl border border-slate-100 hidden xl:block">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center">
                    <ShieldCheck size={24} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">VAT Compliant</p>
                    <p className="text-xl font-black text-slate-900">Verified</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-32 bg-slate-50 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-white to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-20 space-y-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-block px-4 py-1.5 bg-indigo-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest mb-4"
            >
              The Brighter Side of Accounting
            </motion.div>
            <h2 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tight leading-tight max-w-4xl mx-auto">
              Welcome to the <span className="text-indigo-600">Revolution</span> the accounting industry needs.
            </h2>
            <p className="text-xl text-slate-500 font-medium max-w-2xl mx-auto">
              Goodbye expensive, complicated solutions. Hello pure bookkeeping pleasure.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="space-y-10">
              <div className="space-y-6">
                <h3 className="text-3xl font-black text-slate-900 leading-tight">
                  Changing the way people feel about accounting. It's for people, not eggheads.
                </h3>
                <p className="text-lg text-slate-600 font-medium leading-relaxed">
                  BrightLedger is the perfect bookkeeping solution for small business owners, freelancers, and contractors. It's like all the best bits all rolled into one; create and send professional invoices in any currency, track your bills, and spend more time doing what you love.
                </p>
              </div>

              <div className="space-y-8">
                <div className="flex gap-6 p-8 bg-white rounded-[32px] border border-slate-100 shadow-sm hover:shadow-xl transition-shadow group">
                  <div className="shrink-0 w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Zap size={28} />
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-slate-900 mb-2">Makes running business easier</h4>
                    <p className="text-slate-500 font-medium leading-relaxed">
                      BrightLedger makes bookkeeping an easier, less time-consuming, and more enjoyable process. And because it's online, you can use it anytime, wherever you are.
                    </p>
                  </div>
                </div>

                <div className="flex gap-6 p-8 bg-white rounded-[32px] border border-slate-100 shadow-sm hover:shadow-xl transition-shadow group">
                  <div className="shrink-0 w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ShieldCheck size={28} />
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-slate-900 mb-2">See everything clearly</h4>
                    <p className="text-slate-500 font-medium leading-relaxed">
                      BrightLedger gives you a complete view of your business. Helping you to focus on what's most important: getting paid. From the moment you login, you can immediately see who owes you money, who you owe, and what your cashflow is.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-[4/5] bg-indigo-600 rounded-[80px] overflow-hidden shadow-2xl relative">
                <img 
                  src="https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&q=80&w=2000" 
                  alt="Modern Workspace" 
                  className="w-full h-full object-cover opacity-90 mix-blend-multiply"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/80 via-transparent to-transparent" />
                <div className="absolute bottom-12 left-12 right-12 p-8 bg-white/10 backdrop-blur-md rounded-3xl border border-white/20">
                  <p className="text-white text-lg font-bold italic leading-relaxed">
                    "BrightLedger is a breath of fresh air. It actually makes me look forward to doing my invoices."
                  </p>
                  <div className="mt-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-indigo-400 border-2 border-white/30" />
                    <div>
                      <p className="text-sm font-black text-white">David Miller</p>
                      <p className="text-xs font-bold text-white/60 text-indigo-200">Graphic Designer</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating Stat Card */}
              <div className="absolute -top-10 -right-10 bg-white p-6 rounded-3xl shadow-2xl border border-slate-100 max-w-[180px] animate-bounce-slow">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Time Saved</p>
                <p className="text-3xl font-black text-indigo-600">40h+</p>
                <p className="text-xs font-bold text-slate-500 mt-1">Per Month / User</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Who Uses Section */}
      <section className="py-32 overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="relative order-2 lg:order-1">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-indigo-50 rounded-full blur-3xl opacity-50" />
              <div className="relative grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="aspect-[3/4] bg-slate-100 rounded-[32px] overflow-hidden shadow-xl">
                    <img src="https://images.unsplash.com/photo-1544717297-fa154daaf02e?auto=format&fit=crop&q=80&w=600" alt="Freelancer" className="w-full h-full object-cover" />
                  </div>
                  <div className="aspect-square bg-indigo-600 rounded-[32px] flex items-center justify-center p-8 text-white">
                    <div>
                      <p className="text-4xl font-black mb-2">98%</p>
                      <p className="text-xs font-bold uppercase tracking-widest opacity-80">User Satisfaction</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4 pt-12">
                  <div className="aspect-square bg-slate-900 rounded-[32px] overflow-hidden shadow-xl">
                    <img src="https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?auto=format&fit=crop&q=80&w=600" alt="Digital Agency" className="w-full h-full object-cover opacity-80" />
                  </div>
                  <div className="aspect-[3/4] bg-slate-100 rounded-[32px] overflow-hidden shadow-xl">
                    <img src="https://images.unsplash.com/photo-1573164746237-dacaba327ffb?auto=format&fit=crop&q=80&w=600" alt="Contractor" className="w-full h-full object-cover" />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-8 order-1 lg:order-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest">
                Our Community
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 leading-tight">
                Built for those who <span className="text-indigo-600">do.</span>
              </h2>
              <p className="text-lg text-slate-600 font-medium leading-relaxed">
                BrightLedger is the natural home for forward-thinking business owners who want to digitize their workflow. We support a diverse world of entrepreneurs.
              </p>
              
              <div className="space-y-4">
                {[
                  { title: "The Freelancer", desc: "For designers, writers, and artists who need simple invoicing and expense tracking without the accountant jargon." },
                  { title: "The Contractor", desc: "For IT experts and builders who need to track project costs and manage large bills seamlessly." },
                  { title: "The Small Agency", desc: "For teams that need multi-currency support and financial intelligence to scale their operations." }
                ].map((item, idx) => (
                  <div key={idx} className="p-6 rounded-3xl bg-slate-50 border border-slate-100 hover:border-indigo-200 transition-colors cursor-default">
                    <h4 className="text-lg font-black text-slate-900 mb-1">{item.title}</h4>
                    <p className="text-sm text-slate-500 font-medium leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Detailed */}
      <section id="features" className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-24 space-y-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-block px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest mb-4 border border-indigo-100"
            >
              Enterprise-Grade Capabilities
            </motion.div>
            <h2 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tight leading-tight">
              Everything you need to <span className="text-indigo-600">Scale</span>.
            </h2>
            <p className="text-xl text-slate-500 font-medium max-w-2xl mx-auto leading-relaxed">
              We've packed years of accounting expertise into a frictionless interface. Designed specifically for the modern UK business landscape.
            </p>
          </div>

          <div className="space-y-32">
            {/* Feature 1: Invoicing */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
              <div className="space-y-6">
                <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100 mb-8">
                  <FileText size={28} />
                </div>
                <h3 className="text-3xl font-black text-slate-900">Invoicing that commands respect.</h3>
                <p className="text-lg text-slate-600 font-medium leading-relaxed">
                  First impressions matter. Create stunning, professional invoices that reflect your brand's quality.
                </p>
                <ul className="space-y-4">
                  {[
                    "Custom branding & logo integration",
                    "Automated late payment reminders",
                    "Multi-currency support with live rates",
                    "One-click 'Pay Now' buttons for Stripe/PayPal",
                    "Recursive billing for subscription models"
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-3">
                      <CheckCircle2 size={20} className="text-indigo-600 shrink-0" />
                      <span className="text-slate-700 font-bold">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-slate-50 rounded-[48px] p-8 border border-slate-100 shadow-inner group overflow-hidden">
                 <div className="bg-white rounded-3xl shadow-2xl p-8 transform group-hover:scale-105 transition-transform duration-500">
                    <div className="flex justify-between mb-8">
                      <div className="w-12 h-12 bg-indigo-600 rounded-xl" />
                      <div className="text-right">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Invoice #INV-2024-001</p>
                        <p className="text-xl font-black text-slate-900">£2,450.00</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="h-4 bg-slate-100 rounded-full w-3/4" />
                      <div className="h-4 bg-slate-100 rounded-full w-1/2" />
                      <div className="h-20 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-center justify-center">
                         <span className="text-indigo-600 font-black text-xs uppercase tracking-widest tracking-widest">Payment Received</span>
                      </div>
                    </div>
                 </div>
              </div>
            </div>

            {/* Feature 2: Expenses & VAT */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
              <div className="lg:order-2 space-y-6">
                <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-100 mb-8">
                  <PieChart size={28} />
                </div>
                <h3 className="text-3xl font-black text-slate-900">UK VAT & MTD Compliance.</h3>
                <p className="text-lg text-slate-600 font-medium leading-relaxed">
                  Stay on the right side of HMRC effortlessly. Our system is built with Making Tax Digital (MTD) as a core pillar.
                </p>
                <ul className="space-y-4">
                  {[
                    "Automatic VAT calculation as you spend",
                    "Direct linking to HMRC for MTD submissions",
                    "Expense categorization for maximum relief",
                    "Receipt capture via mobile app",
                    "Corporation Tax estimates in real-time"
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-3">
                      <CheckCircle2 size={20} className="text-emerald-600 shrink-0" />
                      <span className="text-slate-700 font-bold">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="lg:order-1 bg-slate-950 rounded-[48px] p-12 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500 blur-[80px] opacity-20" />
                <div className="space-y-8 relative z-10">
                  <div className="flex items-center justify-between">
                     <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">HMRC Status</span>
                     <div className="px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-full text-[8px] font-black uppercase tracking-widest border border-emerald-500/20">Active</div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-bold text-white/60">Estimated Liability</p>
                    <p className="text-4xl font-black text-white">£4,821.50</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                      <p className="text-[8px] font-black text-white/40 uppercase tracking-widest mb-1">Standard Rate</p>
                      <p className="text-lg font-black text-white">20%</p>
                    </div>
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                      <p className="text-[8px] font-black text-white/40 uppercase tracking-widest mb-1">Flat Rate</p>
                      <p className="text-lg font-black text-white">12%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Feature 3: Banking */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
              <div className="space-y-6">
                <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-100 mb-8">
                  <Wallet size={28} />
                </div>
                <h3 className="text-3xl font-black text-slate-900">Seamless Bank Connectivity.</h3>
                <p className="text-lg text-slate-600 font-medium leading-relaxed">
                  Connect your business accounts and let BrightLedger do the heavy lifting of reconciliation.
                </p>
                <div className="grid grid-cols-2 gap-6 pt-4">
                  <div className="space-y-2">
                    <h5 className="font-black text-slate-900">Auto-Matching</h5>
                    <p className="text-sm text-slate-500 font-medium">Smart algorithms match bank statements to invoices automatically.</p>
                  </div>
                  <div className="space-y-2">
                    <h5 className="font-black text-slate-900">Live Sync</h5>
                    <p className="text-sm text-slate-500 font-medium">Daily transaction updates from over 250+ UK financial institutions.</p>
                  </div>
                  <div className="space-y-2">
                    <h5 className="font-black text-slate-900">Bulk Actions</h5>
                    <p className="text-sm text-slate-500 font-medium">Categorize hundreds of transactions with simple drag-and-drop rules.</p>
                  </div>
                  <div className="space-y-2">
                    <h5 className="font-black text-slate-900">Security First</h5>
                    <p className="text-sm text-slate-500 font-medium">Read-only connection via Open Banking. We never see your login credentials.</p>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square bg-slate-100 rounded-[64px] flex items-center justify-center overflow-hidden">
                   <img src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=1200" alt="Banking" className="w-full h-full object-cover opacity-80" />
                </div>
                <div className="absolute -bottom-6 -right-6 p-8 bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-xs">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center">
                      <Smartphone size={18} />
                    </div>
                    <span className="text-xs font-black text-slate-900 uppercase tracking-widest">Mobile Approval</span>
                  </div>
                  <p className="text-sm font-bold text-slate-500">Approve transaction categorization with a swipe on your phone.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Deep Detail Section */}
      <section className="py-32 bg-indigo-900 text-white overflow-hidden relative rounded-[64px] mx-6 mb-12">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-indigo-800 opacity-20 transform skew-x-12 translate-x-1/2" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-widest mb-6">
                Deep Insights
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-8 leading-tight">
                Beyond Bookkeeping: <br />
                <span className="text-indigo-400">Total Business Mastery</span>
              </h2>
              <div className="space-y-8">
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-indigo-400">
                    <PieChart size={24} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">Predictive Cashflow</h4>
                    <p className="text-indigo-100/60 leading-relaxed">
                      Our SaaS-exclusive algorithms analyze 12 months of historical data to predict your bank balance 90 days into the future, helping you decide exactly when to hire, invest, or save.
                    </p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-emerald-400">
                    <ShieldCheck size={24} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">Automated Tax Liability</h4>
                    <p className="text-indigo-100/60 leading-relaxed">
                      Never be surprised by a tax bill again. BrightLedger calculates your Corporation Tax, VAT, and Dividend allowances in real-time as you log every transaction.
                    </p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-amber-400">
                    <Zap size={24} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">Seamless Payment Rails</h4>
                    <p className="text-indigo-100/60 leading-relaxed">
                      Integrated directly with Stripe and GoCardless. Get paid 15 days faster on average with automated payment reminders and one-click 'Pay Now' buttons.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-8 bg-white/5 rounded-[32px] border border-white/10 mt-12">
                  <p className="text-3xl font-black text-indigo-400 mb-2">15k+</p>
                  <p className="text-sm font-bold text-indigo-100/60 uppercase tracking-widest">Active Users</p>
                </div>
                <div className="p-8 bg-white/5 rounded-[32px] border border-white/10">
                  <p className="text-3xl font-black text-emerald-400 mb-2">£2.4B</p>
                  <p className="text-sm font-bold text-indigo-100/60 uppercase tracking-widest">Processed</p>
                </div>
                <div className="p-8 bg-white/5 rounded-[32px] border border-white/10 mt-12">
                  <p className="text-3xl font-black text-amber-400 mb-2">99.9%</p>
                  <p className="text-sm font-bold text-indigo-100/60 uppercase tracking-widest">Uptime Rate</p>
                </div>
                <div className="p-8 bg-white/5 rounded-[32px] border border-white/10">
                  <p className="text-3xl font-black text-rose-400 mb-2">0</p>
                  <p className="text-sm font-bold text-indigo-100/60 uppercase tracking-widest">Failed Audits</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-32 bg-slate-950 text-white rounded-[64px] mx-6">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20 space-y-6">
            <h2 className="text-4xl md:text-5xl font-black tracking-tight">Simple, Transparent <span className="text-indigo-400">Pricing</span></h2>
            
            <div className="flex items-center justify-center gap-4">
              <span className={cn("text-sm font-bold transition-opacity", activePlan === 'monthly' ? "opacity-100" : "opacity-40")}>Monthly</span>
              <button 
                onClick={() => setActivePlan(activePlan === 'monthly' ? 'yearly' : 'monthly')}
                className="w-14 h-8 bg-indigo-600 rounded-full p-1 relative transition-all"
              >
                <div className={cn(
                  "w-6 h-6 bg-white rounded-full transition-transform duration-300 shadow-sm",
                  activePlan === 'yearly' ? "translate-x-6" : "translate-x-0"
                )} />
              </button>
              <span className={cn("text-sm font-bold transition-opacity", activePlan === 'yearly' ? "opacity-100" : "opacity-40")}>
                Yearly <span className="text-emerald-400 ml-2">(-20%)</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {plans.map((plan, i) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={cn(
                  "relative p-10 rounded-[48px] border flex flex-col h-full transition-all",
                  plan.popular 
                    ? "bg-white text-slate-900 border-white shadow-2xl scale-105 z-10" 
                    : "bg-white/5 text-white border-white/10 hover:border-white/20"
                )}
              >
                {plan.popular && (
                  <div className="absolute top-0 right-10 -translate-y-1/2 px-4 py-1.5 bg-indigo-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest">
                    Most Popular
                  </div>
                )}
                
                <div className="mb-10">
                  <h3 className="text-xl font-black mb-2">{plan.name}</h3>
                  <div className="flex items-baseline gap-2">
                    <span className="text-5xl font-black leading-tight">£{plan.price}</span>
                    <span className={cn("text-sm font-bold", plan.popular ? "text-slate-400" : "text-white/40")}>/mo</span>
                  </div>
                  <p className={cn("text-sm font-medium mt-4", plan.popular ? "text-slate-500" : "text-white/60")}>
                    {plan.description}
                  </p>
                </div>

                <div className="space-y-4 flex-1 mb-10">
                  {plan.features.map((feature) => (
                    <div key={feature} className="flex items-center gap-3">
                      <CheckCircle2 size={18} className={plan.popular ? "text-indigo-600" : "text-indigo-400"} />
                      <span className="text-sm font-bold">{feature}</span>
                    </div>
                  ))}
                </div>

                <button className={cn(
                  "w-full py-5 rounded-2xl font-black text-lg transition-all active:scale-95",
                  plan.popular 
                    ? "bg-indigo-600 text-white shadow-xl shadow-indigo-100 hover:bg-indigo-700" 
                    : "bg-white/10 text-white hover:bg-white/20"
                )}>
                  {plan.cta}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-32 bg-slate-50 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 rounded-full text-[10px] font-black uppercase tracking-widest text-slate-400">
                The Origin Story
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 leading-tight">
                How BrightLedger <span className="text-indigo-600">began...</span>
              </h2>
              <div className="space-y-6 text-lg text-slate-600 font-medium leading-relaxed">
                <p>
                  Back in 2023, while preparing their quarterly VAT, our founders realised they were in for a tiresome day trawling through and categorising their bills, invoices, and various account statements.
                </p>
                <p>
                  Trying other accounting software solutions previously had been a frustrating experience. They'd found them overly complicated, expensive, and not for ordinary non-accounting types like them. They both agreed that there must be an easier way.
                </p>
                <p>
                  That afternoon, they decided to make their own simple online bookkeeping solution; one that wouldn't be confusing or expensive. A solution for people, not eggheads.
                </p>
              </div>
              
              <div className="flex items-center gap-12 pt-4">
                <div>
                  <p className="text-3xl font-black text-slate-900">2023</p>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Founded</p>
                </div>
                <div className="w-px h-12 bg-slate-200" />
                <div>
                  <p className="text-3xl font-black text-slate-900">15k+</p>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Happy Users</p>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square bg-white rounded-[64px] shadow-2xl p-4 border border-slate-100 transform rotate-3">
                <div className="w-full h-full rounded-[48px] overflow-hidden">
                  <img src="https://images.unsplash.com/photo-1522071823992-b48e04b7c403?auto=format&fit=crop&q=80&w=1200" alt="Founders" className="w-full h-full object-cover" />
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-indigo-600 rounded-3xl -z-10 animate-pulse" />
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-emerald-400 rounded-full blur-2xl opacity-20 -z-10" />
            </div>
          </div>
        </div>
      </section>

      {/* Security Deep Dive Section */}
      <section className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-10 shadow-lg shadow-indigo-100">
              <ShieldCheck size={40} />
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight">
              As safe as <span className="text-indigo-600">online banking.</span>
            </h2>
            <p className="text-xl text-slate-500 font-medium leading-relaxed">
              BrightLedger has Bank-level security. We use the same level of encryption and protection that global banks use for their sensitive operations.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-10">
              <div className="space-y-4">
                <div className="text-indigo-600 font-black text-2xl">SSL Certified</div>
                <p className="text-sm text-slate-500 font-bold uppercase tracking-widest leading-relaxed">256-Bit Encryption for all data transfers</p>
              </div>
              <div className="space-y-4">
                <div className="text-emerald-600 font-black text-2xl">Daily Backups</div>
                <p className="text-sm text-slate-500 font-bold uppercase tracking-widest leading-relaxed">Your data is safe and redundant across multiple zones</p>
              </div>
              <div className="space-y-4">
                <div className="text-amber-600 font-black text-2xl">99.97% Uptime</div>
                <p className="text-sm text-slate-500 font-bold uppercase tracking-widest leading-relaxed">Enterprise grade hosting infrastructure</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
            <div className="space-y-8">
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight">Get in Touch</h2>
              <p className="text-xl text-slate-500 font-medium leading-relaxed">
                Have questions about our enterprise plans or custom migrations? Our team is here to help you get digitized.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4 group">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                    <Mail size={24} />
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Email Us</p>
                    <p className="text-lg font-bold text-slate-900">hello@brightledger.io</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 group">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                    <MessageSquare size={24} />
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Live Chat</p>
                    <p className="text-lg font-bold text-slate-900">Available Mon-Fri, 9am-6pm</p>
                  </div>
                </div>
              </div>
            </div>

            <form className="bg-slate-50 p-10 rounded-[40px] border border-slate-100 space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Name</label>
                  <input type="text" className="w-full px-4 py-3 bg-white border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 shadow-sm" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Email</label>
                  <input type="email" className="w-full px-4 py-3 bg-white border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 shadow-sm" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Message</label>
                <textarea rows={4} className="w-full px-4 py-3 bg-white border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 shadow-sm" />
              </div>
              <button className="w-full py-4 bg-slate-900 text-white rounded-xl font-black text-sm hover:bg-slate-800 transition-all active:scale-95">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-50 border-t border-slate-100 py-20 px-6 mt-32">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                <Zap size={18} fill="currentColor" />
              </div>
              <span className="text-lg font-black tracking-tight text-slate-900">BrightLedger</span>
            </div>
            <p className="text-sm font-medium text-slate-500 leading-relaxed">
              Accounting for the next generation of entrepreneurs. Simple, smart, and fully digital.
            </p>
          </div>
          
          <div>
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Product</h4>
            <ul className="space-y-4">
              {['Invoicing', 'Expenses', 'Banking', 'Reports'].map(item => (
                <li key={item}><a href="#" className="text-sm font-bold text-slate-600 hover:text-indigo-600 transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Legal</h4>
            <ul className="space-y-4">
              {['Privacy Policy', 'Terms of Service', 'Security'].map(item => (
                <li key={item}><a href="#" className="text-sm font-bold text-slate-600 hover:text-indigo-600 transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Company</h4>
            <ul className="space-y-4">
              {['About', 'Contact', 'Blog'].map(item => (
                <li key={item}><a href="#" className="text-sm font-bold text-slate-600 hover:text-indigo-600 transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs font-bold text-slate-400">© 2024 BrightLedger LLC. All rights reserved.</p>
          <p className="text-xs font-bold text-slate-400 leading-none">Designed with ❤️ for entrepreneurs.</p>
        </div>
      </footer>
    </div>
  );
}
