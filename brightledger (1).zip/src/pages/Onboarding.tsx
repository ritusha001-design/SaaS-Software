import React, { useState } from 'react';
import { db, auth } from '../lib/firebase';
import { collection, addDoc, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Organization } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import { Building2, Save } from 'lucide-react';

interface OnboardingProps {
  onComplete: (org: Organization) => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [name, setName] = useState('');
  const [currency, setCurrency] = useState<'GBP' | 'USD' | 'EUR'>('GBP');
  const [vatRate, setVatRate] = useState(20);
  const [loading, setLoading] = useState(false);

  const handleCreateOrg = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !auth.currentUser) return;

    setLoading(true);
    try {
      const orgData = {
        name,
        currency,
        vatRegistered: true,
        vatRate,
        ownerId: auth.currentUser.uid,
        createdAt: serverTimestamp()
      };

      let docRef;
      try {
        docRef = await addDoc(collection(db, 'organizations'), orgData);
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'organizations');
        return;
      }
      
      // Create owner as member
      try {
        await setDoc(doc(db, 'organizations', docRef.id, 'members', auth.currentUser.uid), {
          userId: auth.currentUser.uid,
          role: 'admin',
          email: auth.currentUser.email
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `organizations/${docRef.id}/members/${auth.currentUser.uid}`);
        return;
      }

      onComplete({ id: docRef.id, ...orgData, createdAt: new Date().toISOString() } as Organization);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-0 pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-indigo-50 rounded-full blur-3xl opacity-50" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-slate-100 rounded-full blur-3xl opacity-50" />
      </div>

      <div className="max-w-md w-full bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-slate-200 p-10 relative z-10">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-6 shadow-xl shadow-indigo-100 transform rotate-3">
            <Building2 size={32} />
          </div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Set up your profile</h2>
          <p className="text-slate-500 font-medium mt-2">Let's create your workspace to get started.</p>
        </div>

        <form onSubmit={handleCreateOrg} className="space-y-8">
          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-700 ml-1">Company Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              placeholder="e.g. Acme Studio Ltd"
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium placeholder:text-slate-400 shadow-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 ml-1">Currency</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as 'GBP' | 'USD' | 'EUR')}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium shadow-sm appearance-none cursor-pointer"
              >
                <option value="GBP">GBP (£)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 ml-1">VAT Rate (%)</label>
              <input
                type="number"
                value={vatRate}
                onChange={(e) => setVatRate(Number(e.target.value))}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium shadow-sm"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-indigo-600 text-white px-8 py-5 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all active:scale-[0.98] disabled:opacity-50 shadow-xl shadow-indigo-100 mt-4 group"
          >
            {loading ? (
               <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Save size={20} className="group-hover:scale-110 transition-transform" />
                <span>Launch Workplace</span>
              </>
            )}
          </button>

          <p className="text-center text-xs text-slate-400 font-medium">
            You can always change these settings later in your dashboard.
          </p>
        </form>
      </div>
    </div>
  );
}
