import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, db } from './lib/firebase';
import { doc, getDoc, setDoc, query, collection, where, getDocs, serverTimestamp } from 'firebase/firestore';
import { UserProfile, Organization } from './types';
import { handleFirestoreError, OperationType } from './lib/firestoreUtils';

// Components (Lazy or direct)
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Invoices from './pages/Invoices';
import Expenses from './pages/Expenses';
import Clients from './pages/Clients';
import Settings from './pages/Settings';
import Banking from './pages/Banking';
import Bills from './pages/Bills';
import Reports from './pages/Reports';
import Login from './pages/Login';
import Landing from './pages/Landing';
import Onboarding from './pages/Onboarding';
import AdminDashboard from './pages/AdminDashboard';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [org, setOrg] = useState<Organization | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      if (firebaseUser) {
        setUser(firebaseUser);
        // Sync profile
        let superAdminStatus = false;
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (!userDoc.exists()) {
            superAdminStatus = firebaseUser.email === 'ritusha001@gmail.com';
            await setDoc(doc(db, 'users', firebaseUser.uid), {
              email: firebaseUser.email,
              displayName: firebaseUser.displayName || null,
              photoURL: firebaseUser.photoURL || null,
              createdAt: serverTimestamp(),
              isSuperAdmin: superAdminStatus
            });
          } else {
            const data = userDoc.data();
            superAdminStatus = data?.isSuperAdmin || firebaseUser.email === 'ritusha001@gmail.com';
            
            // Auto-promote if they are the designated admin but not yet flagged in DB
            if (firebaseUser.email === 'ritusha001@gmail.com' && !data?.isSuperAdmin) {
              await setDoc(doc(db, 'users', firebaseUser.uid), { 
                isSuperAdmin: true,
                updatedAt: serverTimestamp()
              }, { merge: true });
            }
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${firebaseUser.uid}`);
        }
        setProfile({
          uid: firebaseUser.uid,
          email: firebaseUser.email!,
          displayName: firebaseUser.displayName || undefined,
          photoURL: firebaseUser.photoURL || undefined,
          isSuperAdmin: superAdminStatus
        });

        // Load organization (first one for now)
        const q = query(collection(db, 'organizations'), where('ownerId', '==', firebaseUser.uid));
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
          const firstOrg = querySnapshot.docs[0];
          setOrg({ id: firstOrg.id, ...firstOrg.data() } as Organization);
        } else {
          // Check memberships if not owner
          // (Skipping complex multi-org memberships for MVP)
        }
      } else {
        setUser(null);
        setProfile(null);
        setOrg(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        {!user ? (
          <>
            <Route path="/" element={<Landing />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </>
        ) : !org ? (
          <>
            <Route path="/onboarding" element={<Onboarding onComplete={(newOrg) => setOrg(newOrg)} />} />
            <Route path="*" element={<Navigate to="/onboarding" replace />} />
          </>
        ) : (
          <Route element={<Layout org={org} profile={profile!} />}>
            <Route path="/" element={<Dashboard org={org} />} />
            <Route path="/banking" element={<Banking org={org} />} />
            <Route path="/invoices" element={<Invoices org={org} />} />
            <Route path="/expenses" element={<Expenses org={org} />} />
            <Route path="/bills" element={<Bills org={org} />} />
            <Route path="/clients" element={<Clients org={org} />} />
            <Route path="/reports" element={<Reports org={org} />} />
            <Route path="/settings" element={<Settings org={org} onUpdate={(updated) => setOrg(updated)} />} />
            {profile?.isSuperAdmin && <Route path="/admin" element={<AdminDashboard />} />}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        )}
      </Routes>
    </Router>
  );
}
