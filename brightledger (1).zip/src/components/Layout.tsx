import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  FileText, 
  Receipt, 
  Users, 
  Settings, 
  LogOut,
  ChevronDown,
  Plus,
  Bell,
  Wallet,
  ClipboardList,
  BarChart3,
  Zap,
  ShieldAlert
} from 'lucide-react';
import { cn } from '../lib/utils';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';
import { Organization, UserProfile } from '../types';

interface LayoutProps {
  org: Organization;
  profile: UserProfile;
}

export default function Layout({ org, profile }: LayoutProps) {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    { name: 'Banking', icon: Wallet, path: '/banking' },
    { name: 'Invoices', icon: FileText, path: '/invoices' },
    { name: 'Expenses', icon: Receipt, path: '/expenses' },
    { name: 'Bills', icon: ClipboardList, path: '/bills' },
    { name: 'Clients', icon: Users, path: '/clients' },
    { name: 'Reports', icon: BarChart3, path: '/reports' },
    { name: 'Settings', icon: Settings, path: '/settings' },
  ];

  if (profile.isSuperAdmin) {
    menuItems.push({ name: 'Admin Control', icon: ShieldAlert, path: '/admin' });
  }

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden font-sans text-slate-900">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0">
        <div className="p-8 border-b border-slate-100 flex items-center gap-3 group cursor-pointer">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100 transform -rotate-3 group-hover:rotate-0 transition-transform duration-300">
            <Zap size={22} fill="currentColor" />
          </div>
          <span className="font-black text-2xl tracking-tighter text-slate-900 underline decoration-indigo-500 decoration-2 underline-offset-4">BrightLedger</span>
        </div>

        <nav className="flex-1 px-4 py-8 space-y-1.5 overflow-y-auto">
          <p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Main Menu</p>
          {menuItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm",
                  isActive 
                    ? "bg-indigo-50 text-indigo-700 shadow-sm shadow-indigo-100/50" 
                    : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                )
              }
            >
              <item.icon size={18} className="shrink-0" />
              <span>{item.name}</span>
            </NavLink>
          ))}
        </nav>

        <div className="p-6 border-t border-slate-100 space-y-6">
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase tracking-widest font-black text-emerald-700">Live MTD</span>
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse ring-4 ring-emerald-100"></div>
            </div>
            <p className="text-xs text-emerald-800 font-bold">HMRC Linked: 26-27</p>
          </div>

          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-3 w-full rounded-xl text-slate-500 hover:bg-rose-50 hover:text-rose-600 transition-all text-sm font-bold group"
          >
            <LogOut size={18} className="group-hover:translate-x-0.5 transition-transform" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-20 bg-white border-b border-slate-200 px-10 flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1.5">Active Workspace</span>
              <div className="flex items-center gap-2 group cursor-pointer">
                <span className="text-lg font-bold text-slate-900 leading-none">{org.name}</span>
                <div className="p-1 rounded-md bg-slate-50 group-hover:bg-slate-100 transition-colors">
                  <ChevronDown size={14} className="text-slate-400 group-hover:text-slate-600 transition-colors" />
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <button className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all relative group">
                <Bell size={20} />
                <div className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white ring-2 ring-transparent group-hover:ring-indigo-100 transition-all"></div>
              </button>
              <button className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all">
                <Plus size={20} />
              </button>
            </div>
            
            <div className="h-10 w-px bg-slate-100" />
            
            <div className="flex items-center gap-4 group cursor-pointer">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-900 leading-none group-hover:text-indigo-600 transition-colors">{profile.displayName || 'Account Holder'}</p>
                <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest font-bold">Admin Level Access</p>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-slate-100 flex items-center justify-center border-2 border-white shadow-sm overflow-hidden ring-4 ring-slate-50 group-hover:ring-indigo-50 transition-all">
                {profile.photoURL ? (
                  <img src={profile.photoURL} alt="" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm font-black text-slate-400">
                    {(profile.displayName || profile.email).charAt(0).toUpperCase()}
                  </span>
                )}
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto bg-slate-50/50">
          <div className="p-8 max-w-[1400px] mx-auto">
            <Outlet />
          </div>
        </div>

        <footer className="px-8 py-3 bg-white border-t border-slate-200 text-[10px] text-slate-400 flex justify-between shrink-0">
          <div>BrightLedger SaaS v1.0.0 • Multi-tenant Node: UK-LDN-01</div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-indigo-600 transition-colors">Support</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Compliance</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Security</a>
          </div>
        </footer>
      </main>
    </div>
  );
}
