export type Role = 'superadmin' | 'admin' | 'accountant' | 'staff';

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  isSuperAdmin?: boolean;
}

export interface Organization {
  id: string;
  name: string;
  address?: string;
  taxId?: string;
  currency: 'GBP' | 'USD' | 'EUR';
  vatRegistered: boolean;
  vatRate: number;
  fiscalYearEnd?: string;
  ownerId: string;
  createdAt: string;
}

export interface Member {
  userId: string;
  role: Role;
  email: string;
}

export interface Client {
  id: string;
  orgId: string;
  name: string;
  email?: string;
  address?: string;
  taxId?: string;
  createdAt: string;
}

export interface Invoice {
  id: string;
  orgId: string;
  clientId: string;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  currency: string;
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'void';
  subtotal: number;
  vatTotal: number;
  total: number;
  notes?: string;
  createdAt: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  vatRate: number;
  total: number;
}

export interface Expense {
  id: string;
  orgId: string;
  category: string;
  amount: number;
  vatAmount: number;
  currency: string;
  date: string;
  description: string;
  receiptUrl?: string;
  supplier?: string;
  status: 'pending' | 'cleared' | 'void';
  createdAt: string;
}

export interface Bill {
  id: string;
  orgId: string;
  supplier: string;
  billNumber?: string;
  issueDate: string;
  dueDate: string;
  subtotal: number;
  vatTotal: number;
  total: number;
  status: 'unpaid' | 'paid' | 'overdue';
  createdAt: string;
}

export interface Payment {
  id: string;
  orgId: string;
  invoiceId: string;
  amount: number;
  date: string;
  method: 'stripe' | 'bank_transfer' | 'cash' | 'other';
  reference?: string;
  createdAt: string;
}

export interface VatRecord {
  id: string;
  orgId: string;
  periodStart: string;
  periodEnd: string;
  totalSalesVat: number;
  totalPurchaseVat: number;
  netVat: number;
  status: 'draft' | 'submitted';
  createdAt: string;
}

export interface Transaction {
  id: string;
  orgId: string;
  type: 'income' | 'expense';
  amount: number;
  date: string;
  description: string;
  referenceId?: string;
  category?: string;
  createdAt: string;
}
